Imports System
Imports System.Data
Imports System.Linq

Module Program
    Sub Main()
        ' Create a table that simulates a CSV file without headers
        Dim dt As New DataTable()
        dt.Columns.Add("Col0")
        dt.Columns.Add("Col1")
        dt.Columns.Add("Col2")
        dt.Columns.Add("Col3")
        dt.Columns.Add("Col4")
        dt.Columns.Add("Col5")

        ' Add rows (first row simulates headers)
        dt.Rows.Add("audit ref", "action ref", "target date", "remove1", "extra", "remove2")
        dt.Rows.Add("A001", "ACT100", "2024-01-01", "x", "val1", "x")
        dt.Rows.Add("A001", "ACT101", "2024-03-15", "x", "val2", "x")
        dt.Rows.Add("A002", "ACT200", "2024-02-20", "x", "val3", "x")
        dt.Rows.Add("A002", "ACT201", "2024-02-10", "x", "val4", "x")

        ' Remove unwanted columns
        dt.Columns.RemoveAt(5)
        dt.Columns.RemoveAt(3)

        ' Promote first row to headers
        Dim expectedHeaders = {"audit ref", "action ref", "target date", "extra"}
        Dim headerRow = dt.Rows(0)
        For i As Integer = 0 To expectedHeaders.Length - 1
            If headerRow(i).ToString().Trim().ToLower() <> expectedHeaders(i) Then
                Console.WriteLine($"Header mismatch at column {i}: Found '{headerRow(i)}'")
                Return
            End If
        Next

        For i As Integer = 0 To dt.Columns.Count - 1
            dt.Columns(i).ColumnName = dt.Rows(0)(i).ToString()
        Next
        dt.Rows.RemoveAt(0)

        ' Group and find latest date
        Dim grouped = From row In dt.AsEnumerable()
                      Group row By auditRef = row.Field(Of String)("audit ref") Into Group
                      Select auditRef,
                             LatestDate = Group.Max(Function(r) DateTime.Parse(r.Field(Of String)("target date")))

        Console.WriteLine("Latest target date per audit ref:")
        For Each item In grouped
            Console.WriteLine($"{item.auditRef} => {item.LatestDate.ToShortDateString()}")
        Next

        Console.ReadLine()
    End Sub
End Module
